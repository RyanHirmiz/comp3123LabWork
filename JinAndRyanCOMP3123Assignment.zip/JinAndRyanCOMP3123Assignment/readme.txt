***README***

Team Member #1: Jin Kwan Kim
Student ID: 101058670
Email: JinKwan.Kim@georgebrown.ca

Team Member #2: Ryan Hirmiz
Student ID: 101086605
Email: Ryan.Hirmiz@georgebrown.ca

***PLEASE BE AWARE****

Please be aware, that NodeModules have to be coded in both the frontend and backend folders, otherwise the project won't show up on the webpage.