//Team Member #1: Jin Kwan Kim
//Student ID: 101058670

//Team Member #2: Ryan Hirmiz
//Student ID: 101086605

export class Movie{
    id:number;
    title: string;
    runningtime: string;
    genre: string;
    rating: string;
    director: string;
    status: string;
}