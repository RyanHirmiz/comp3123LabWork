
//Team Member #1: Jin Kwan Kim
//Student ID: 101058670

//Team Member #2: Ryan Hirmiz
//Student ID: 101086605

import {Movie } from './movie';
export const MOVIES: Movie[] =
[
    {id: 1, title: "Lord Of The Rings", runningtime:"130 Minutes", genre: "Fantasy", rating: "4 stars", director:"Peter Jackson", status: "Available"},
    {id: 2, title: "Scream", runningtime:"130 Minutes", genre: "Horror", rating: "3.5 stars", director:"Wes Craven", status: "Available"},
    {id: 3, title: "Star Wars", runningtime:"110 Minutes", genre: "Science Fiction", rating: "5 stars", director:"George Lucas", status: "Available"},
]

